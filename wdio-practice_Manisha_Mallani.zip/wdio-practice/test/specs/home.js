
describe('Home', ()=>{
 it('User should be able to submit form with all required fields filled in', async ()=>{
    const assert = require('assert');
    const currentAgeInput = $('#current-age');
    const retirementAgeInput = $('#retirement-age');
    const currentIncomeInput = $('#current-income');
    const spouseIncomeInput = $('#spouse-income');
    const currentTotalSavingsInput = $('#current-total-savings');
    const currentAnnualSavingsInput = $('#current-annual-savings');
    const savingsIncreaseRateInput = $('#savings-increase-rate');
    const noSocialBenefitsCheckbox = $('//label[@for="no-social-benefits"]');
    const calculateButton = $('//button[normalize-space()="Calculate"]');
    const verifyResult = $('#result-message');
    const expected = "In order to retire by 68, you might need to consider increasing your monthly savings by $57 a month.";

     //open URL 
     await browser.url("https://www.securian.com/insights-tools/retirement-calculator.html");
     browser.maximizeWindow();

     await currentAgeInput.addValue('40');
     await retirementAgeInput.addValue('68');
     
     currentIncomeInput.click();
     await currentIncomeInput.addValue('100000');
    
     spouseIncomeInput.click();
     await spouseIncomeInput.addValue('75000');
    
     
     currentTotalSavingsInput.click();
     await currentTotalSavingsInput.addValue('500000');

     await currentAnnualSavingsInput.addValue('10');
     await savingsIncreaseRateInput.addValue('2');
     await noSocialBenefitsCheckbox.click(); 
     
 
     //calculate 
     await calculateButton.click();

     //verify
     browser.pause(1000);
     await verifyResult.waitForDisplayed();
     const actual = await verifyResult.getText();
     console.log('Actual: ' + actual);
     assert.strictEqual(actual, expected);
 
 }),

 it('Additional Social Security fields should display/hide based on Social Security benefits toggle', async ()=>{
    const assert = require('assert');
    const currentAgeInput = $('#current-age');
    const retirementAgeInput = $('#retirement-age');
    const currentIncomeInput = $('#current-income');
    const spouseIncomeInput = $('#spouse-income');
    const currentTotalSavingsInput = $('#current-total-savings');
    const currentAnnualSavingsInput = $('#current-annual-savings');
    const savingsIncreaseRateInput = $('#savings-increase-rate');
    const yesSocialBenefitsCheckbox = $('//label[@for="yes-social-benefits"]');
    const maritialstatus = $('#marital-status-label')
    const noSocialBenefitsCheckbox = $('//label[@for="no-social-benefits"]');

     //open URL 
     await browser.url("https://www.securian.com/insights-tools/retirement-calculator.html");
     browser.maximizeWindow();

     await currentAgeInput.addValue('40');
     await retirementAgeInput.addValue('68');
     
     currentIncomeInput.click();
     await currentIncomeInput.addValue('100000');
    
     spouseIncomeInput.click();
     await spouseIncomeInput.addValue('75000');
    
     
     currentTotalSavingsInput.click();
     await currentTotalSavingsInput.addValue('500000');

     await currentAnnualSavingsInput.addValue('10');
     await savingsIncreaseRateInput.addValue('2');
     await yesSocialBenefitsCheckbox.click(); 
     
    browser.waitUntil(() => {
    return parentElem.$(maritialstatus).isDisplayed();
  }, {
    timeout: 5000,
    timeoutMsg: 'Additional Social Security fields are not displayed after 5 seconds'
  });
  
  await noSocialBenefitsCheckbox.click();

 
 }),

 it('User should be able to submit form with all fields filled in', async ()=>{
    const assert = require('assert');
    const currentAgeInput = $('#current-age');
    const retirementAgeInput = $('#retirement-age');
    const currentIncomeInput = $('#current-income');
    const spouseIncomeInput = $('#spouse-income');
    const currentTotalSavingsInput = $('#current-total-savings');
    const currentAnnualSavingsInput = $('#current-annual-savings');
    const savingsIncreaseRateInput = $('#savings-increase-rate');
    const yesSocialBenefitsCheckbox = $('label[for="yes-social-benefits"]');
    const socialSecurityOverrideAmmountInput = $('#social-security-override');
    const calculateButton = $('//button[normalize-space()="Calculate"]');
    const verifyResult = $('#result-message');
    const expected = "Congratulations! You are exceeding your retirement goals. You are saving an extra $283 a month.";

     //open URL 
     await browser.url("https://www.securian.com/insights-tools/retirement-calculator.html");
     browser.maximizeWindow();

     await currentAgeInput.addValue('40');
     await retirementAgeInput.addValue('68');
     
     currentIncomeInput.click();
     await currentIncomeInput.addValue('100000');
    
     spouseIncomeInput.click();
     await spouseIncomeInput.addValue('75000');
    
     
     currentTotalSavingsInput.click();
     await currentTotalSavingsInput.addValue('500000');

     await currentAnnualSavingsInput.addValue('10');
     await savingsIncreaseRateInput.addValue('2');
     await yesSocialBenefitsCheckbox.click(); 
     
       
    browser.waitUntil(() => {
      return parentElem.$(socialSecurityOverrideAmmountInput).isDisplayed();
    }, {
      timeout: 5000,
      timeoutMsg: 'Additional Social Security fields are not displayed after 5 seconds'
    });

     
    socialSecurityOverrideAmmountInput.click();
     await socialSecurityOverrideAmmountInput.setValue("1000");
     
    
     //calculate 
     await calculateButton.click();

     //verify
     browser.pause(1000);
     await verifyResult.waitForDisplayed();
     const actual = await verifyResult.getText();
     console.log('Actual: ' + actual);
     assert.strictEqual(actual, expected);
 
 }),
 
 it('User should be able to update default calculator values', async ()=>{
  const assert = require('assert');
  const currentAgeInput = $('#current-age');
  const retirementAgeInput = $('#retirement-age');
  const currentIncomeInput = $('#current-income');
  const spouseIncomeInput = $('#spouse-income');
  const currentTotalSavingsInput = $('#current-total-savings');
  const currentAnnualSavingsInput = $('#current-annual-savings');
  const savingsIncreaseRateInput = $('#savings-increase-rate');
  const yesSocialBenefitsCheckbox = $('label[for="yes-social-benefits"]');
  const socialSecurityOverrideAmmountInput = $('#social-security-override');
  const adjustDefaultValueLink = $('ul[role="presentation"] a[role="button"]');
  const additionalIncome = $('#additional-income');
  const retirementDuration = $('#retirement-duration'); 
  const retirementAnnualIncome = $('#retirement-annual-income');
  const preRetirementRoi = $('#pre-retirement-roi');
  const postRetirementRoi = $('#post-retirement-roi');
  const saveChanges = $('//button[normalize-space()="Save changes"]');
  const verifyResult = $('#result-message');
  const expected = "$100";

   //open URL 
   await browser.url("https://www.securian.com/insights-tools/retirement-calculator.html");
   browser.maximizeWindow();

   await currentAgeInput.addValue('40');
   await retirementAgeInput.addValue('68');
   
   currentIncomeInput.click();
   await currentIncomeInput.addValue('100000');
  
   spouseIncomeInput.click();
   await spouseIncomeInput.addValue('75000');
  
   
   currentTotalSavingsInput.click();
   await currentTotalSavingsInput.addValue('500000');

   await currentAnnualSavingsInput.addValue('10');
   await savingsIncreaseRateInput.addValue('2');
   await yesSocialBenefitsCheckbox.click(); 
   socialSecurityOverrideAmmountInput.click();
   await socialSecurityOverrideAmmountInput.setValue("1000");
   adjustDefaultValueLink.click();
     
  browser.waitUntil(() => {
    return parentElem.$(additionalIncome).isDisplayed();
  }, {
    timeout: 5000,
    timeoutMsg: 'Default Calculator values are not displayed after 5 seconds'
  });

  await additionalIncome.click();
  await additionalIncome.addValue('100');
  await retirementDuration.click();
  await retirementDuration.addValue('3');
  
  await retirementAnnualIncome.addValue('2');
  await preRetirementRoi.addValue('4');
  await postRetirementRoi.addValue('2');
   
  saveChanges.click();
  
  browser.waitUntil(() => {
    return parentElem.$(adjustDefaultValueLink).isDisplayed();
  }, {
    timeout: 5000,
    timeoutMsg: 'Adjust Default values are not displayed after 5 seconds'
  });

  await adjustDefaultValueLink.click();

  

//verify
browser.pause(1000);
await additionalIncome.waitForDisplayed();
additionalIncome.click();
const actual = await additionalIncome.getValue();
console.log('Actual: ' + actual);
assert.strictEqual(actual, expected);

});
 
 });
 